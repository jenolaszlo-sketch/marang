#!/usr/bin/env bash
set -Eeuo pipefail
sha=e267f1c16b5cd7dc56ac33b65971be3d712fc673
workspace=/home/gaga/aaaw-m6-1-qualification-e267f1c16b5cd7dc56ac33b65971be3d712fc673
report=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m6-1/linux-native
bundle=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m6-1/source-e267f1c.bundle
sdkroot=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
runid=m6-1-e267f1c-$(date +%s)
parent=/sys/fs/cgroup/aaaw-m5-$runid
test ! -e "$workspace"
runuser -u gaga -- git clone "$bundle" "$workspace" > "$report/clone.log" 2>&1
runuser -u gaga -- git -C "$workspace" checkout --detach "$sha" >> "$report/clone.log" 2>&1
test "$(runuser -u gaga -- git -C "$workspace" rev-parse HEAD)" = "$sha"
test -z "$(runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all)"
{
 echo "source=$sha"
 echo "workspace=$workspace"
 echo "sourceStartClean=true"
 echo "runid=$runid"
 echo "expectedCgroup=$parent"
 uname -a
 "$sdkroot/dotnet" --info
 sha256sum "$bundle"
} > "$report/start.txt"
set +e
bash "$workspace/eng/aaaw-m5-linux-delegated.sh" "$workspace" "$sdkroot" "$runid" python3 eng/qualify-aaaw-m6-1.py > "$report/console.log" 2>&1
result=$?
set -e
cp "$workspace/artifacts/aaaw-m6-1/linux-qualification/qualification.json" "$report/qualification.json"
cp "$workspace/artifacts/aaaw-m6-1/linux-qualification/captured-artifacts.zip" "$report/captured-artifacts.zip"
status=$(runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all)
{
 echo "source=$(runuser -u gaga -- git -C "$workspace" rev-parse HEAD)"
 echo "qualificationExit=$result"
 echo "sourceEndClean=$([[ -z "$status" ]] && echo true || echo false)"
 echo "cgroupParentRemoved=$([[ ! -e "$parent" ]] && echo true || echo false)"
} > "$report/end.txt"
sha256sum "$report/qualification.json" "$report/captured-artifacts.zip" > "$report/export.sha256"
cat "$report/end.txt"
tail -n 20 "$report/console.log"
test -z "$status"
test ! -e "$parent"
exit "$result"