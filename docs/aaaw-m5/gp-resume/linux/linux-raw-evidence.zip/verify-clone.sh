set -euo pipefail
cd /home/gaga
workspace=/home/gaga/aaaw-m5-gp-qualification-b9df4b6fa9d1553b5f2df95dceebb699238ce935
sha=b9df4b6fa9d1553b5f2df95dceebb699238ce935
report=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m5/linux-gp-m5
actual=$(runuser -u gaga -- git -C "$workspace" rev-parse HEAD)
test "$actual" = "$sha"
status=$(runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all)
test -z "$status"
printf 'sourceSha=%s\nsourceStartClean=true\nsourceStatus=%s\nworkspace=%s\n' "$actual" "$status" "$workspace" | tee "$report/source-start.txt"
cat "$report/clone.log"
cat "$report/bundle-heads.log"