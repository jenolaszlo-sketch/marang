#!/usr/bin/env bash
set -euo pipefail
cd /home/gaga
workspace=/home/gaga/aaaw-m5-gp-qualification-b9df4b6fa9d1553b5f2df95dceebb699238ce935
report=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m5/linux-gp-m5
cp "$workspace/artifacts/aaaw-m5/linux-qualification/qualification.json" "$report/qualification.json"
tar -czf "$report/qualification-evidence.tar.gz" -C "$workspace" \
  artifacts/aaaw-m4/process-probes \
  artifacts/aaaw-m5/linux-qualification \
  artifacts/aaaw-m5/process-probes
sha256sum "$report/source-b9df4b6.bundle" "$report/qualification.json" "$report/qualification-evidence.tar.gz" | tee "$report/export-sha256.txt"
sha=$(runuser -u gaga -- git -C "$workspace" rev-parse HEAD)
status=$(runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all)
cat > "$report/source-final-verification.txt" <<EOF
sourceSha=$sha
sourceEndClean=$([ -z "$status" ] && echo true || echo false)
sourceStatus=$status
workspace=$workspace
EOF
cat "$report/source-final-verification.txt"
test "$sha" = b9df4b6fa9d1553b5f2df95dceebb699238ce935
test -z "$status"