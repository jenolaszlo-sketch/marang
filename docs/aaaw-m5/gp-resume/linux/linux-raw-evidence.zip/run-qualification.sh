#!/usr/bin/env bash
set -euo pipefail
cd /home/gaga
workspace=/home/gaga/aaaw-m5-gp-qualification-b9df4b6fa9d1553b5f2df95dceebb699238ce935
sdkroot=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
sha=b9df4b6fa9d1553b5f2df95dceebb699238ce935
runid=gp-m5-b9df4b6-linux-$(date +%s)-$RANDOM
report=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m5/linux-gp-m5
parent=/sys/fs/cgroup/aaaw-m5-$runid
actual=$(runuser -u gaga -- git -C "$workspace" rev-parse HEAD)
test "$actual" = "$sha"
status=$(runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all)
test -z "$status"
{
  echo "sourceSha=$actual"
  echo "sourceStartClean=true"
  echo "workspace=$workspace"
  echo "sdkroot=$sdkroot"
  echo "sdkVersion=$("$sdkroot/dotnet" --version)"
  echo "runid=$runid"
  echo "expectedCgroup=$parent"
  echo "command=bash eng/aaaw-m5-linux-delegated.sh $workspace $sdkroot $runid python3 eng/qualify-aaaw-m5.py"
  echo "kernel=$(uname -a)"
  echo "cgroupMount=$(stat -fc %T /sys/fs/cgroup)"
  echo "packageInputs:"
  sha256sum "$workspace/artifacts/aaaw-m1/packages"/*.nupkg
} | tee "$report/qualification-start.txt"
set +e
runuser -u root -- bash "$workspace/eng/aaaw-m5-linux-delegated.sh" "$workspace" "$sdkroot" "$runid" python3 eng/qualify-aaaw-m5.py > "$report/qualification-console.log" 2>&1
result=$?
set -e
cat "$report/qualification-console.log"
actual_end=$(runuser -u gaga -- git -C "$workspace" rev-parse HEAD)
status_end=$(runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all)
{
  echo "sourceSha=$actual_end"
  echo "sourceEndClean=$([[ -z "$status_end" ]] && echo true || echo false)"
  echo "sourceStatus<<EOF"
  echo "$status_end"
  echo "EOF"
  echo "qualificationExit=$result"
  if [ -e "$parent" ]; then
    echo "cgroupParentRemoved=false"
    cat "$parent/cgroup.events"
  else
    echo "cgroupParentRemoved=true"
  fi
} | tee "$report/qualification-end.txt"
test "$actual_end" = "$sha"
test -z "$status_end"
test ! -e "$parent"
exit "$result"