#!/usr/bin/env bash
set -euo pipefail
cd /home/gaga
bundle=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m5/gp-resume/marang.bundle
workspace=/home/gaga/aaaw-m5-gp-qualification-b9df4b6fa9d1553b5f2df95dceebb699238ce935
sha=b9df4b6fa9d1553b5f2df95dceebb699238ce935
report=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m5/linux-gp-m5
printf 'sourceSha=%s\n' "$sha" > "$report/expected-source.sha"
sha256sum "$bundle" | tee "$report/bundle.sha256"
git bundle list-heads "$bundle" > "$report/bundle-heads.log"
if [ -e "$workspace" ]; then echo "workspace already exists: $workspace" >&2; exit 1; fi
runuser -u gaga -- git clone "$bundle" "$workspace" > "$report/clone.log" 2>&1
runuser -u gaga -- git -C "$workspace" checkout --detach "$sha" >> "$report/clone.log" 2>&1
actual=$(git -C "$workspace" rev-parse HEAD)
test "$actual" = "$sha"
status=$(git -C "$workspace" status --porcelain=v1 --untracked-files=all)
test -z "$status"
printf 'sourceSha=%s\nsourceStartClean=true\nsourceStatus=%s\nworkspace=%s\n' "$actual" "$status" "$workspace" | tee "$report/source-start.txt"
cat "$report/clone.log"
cat "$report/bundle-heads.log"