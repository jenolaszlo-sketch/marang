#!/usr/bin/env bash
set -euo pipefail
cd /home/gaga
workspace=/home/gaga/aaaw-m5-gp-qualification-b9df4b6fa9d1553b5f2df95dceebb699238ce935
source_packages=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m1/packages
report=/mnt/c/Users/Laszlos/source/repos/Solo/aaaw-m5/marang/artifacts/aaaw-m5/linux-gp-m5
mkdir -p "$workspace/artifacts/aaaw-m1/packages"
cp "$source_packages/Penghou.Zhinu.0.2.0-preview.4-aaaw-m1.3.nupkg" "$workspace/artifacts/aaaw-m1/packages/"
cp "$source_packages/Penghou.Zhinu.Sqlite.0.2.0-preview.4-aaaw-m1.3.nupkg" "$workspace/artifacts/aaaw-m1/packages/"
cp "$source_packages/Penghou.Qingniao.Abstractions.0.1.0-preview.5-aaaw-m1.4.nupkg" "$workspace/artifacts/aaaw-m1/packages/"
cp "$source_packages/Penghou.Qingniao.0.1.0-preview.5-aaaw-m1.4.nupkg" "$workspace/artifacts/aaaw-m1/packages/"
for name in Gagamba.Execution Gagamba.Execution.Linux Gagamba.Execution.MacOS Gagamba.Execution.Windows Gagamba.Runtime; do
  file=$(find "$source_packages" -maxdepth 1 -type f -name "$name.0.1.0-preview.4-gp-m5.1.nupkg" -print -quit)
  test -n "$file"
  cp "$file" "$workspace/artifacts/aaaw-m1/packages/"
done
chown -R gaga:gaga "$workspace/artifacts"
sha256sum "$workspace/artifacts/aaaw-m1/packages"/*.nupkg | tee "$report/package-inputs.sha256"
runuser -u gaga -- git -C "$workspace" status --porcelain=v1 --untracked-files=all | tee "$report/source-status-after-package-copy.txt"