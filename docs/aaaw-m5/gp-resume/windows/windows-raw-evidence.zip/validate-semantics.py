import importlib.util
import json
from pathlib import Path
from datetime import datetime
import zipfile

root = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('m5_shared', root / 'eng/qualify-aaaw-m5.py')
shared = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shared)
output = Path(__file__).resolve().parent
record = json.loads((output / 'qualification.json').read_text(encoding='utf-8-sig'))
started = datetime.fromisoformat(record['startedAt']).timestamp()
scenario = shared.find_newest(root / 'artifacts/aaaw-m4/process-probes', 'multi-effect-result.json', started)
partial = shared.find_newest(root / 'artifacts/aaaw-m4/process-probes', 'multi-effect-K4-result.json', started)
control = shared.find_newest(root / 'artifacts/aaaw-m5/process-probes', 'multi-effect-reconcile-2.json', started)
assert scenario and partial and control, 'Missing fresh semantic output'
observed = {
    'sourceSha': record['sourceCommit'],
    'canonical': shared.check_m4_scenario(scenario, started),
    'partial': shared.check_k4(partial, started),
    'barriers': shared.check_barriers(scenario.parent, partial.parent, started),
    'actualStateControl': shared.check_negative_control(control.parent, started),
    'packageInputs': shared.validate_package_lock(shared.M5_LOCK, require_runtime_set=True),
}
observed['passed'] = (record['qualificationPassed']
    and observed['canonical']['verified'] and observed['partial']['verified']
    and len(observed['barriers']) == 12 and all(b['verified'] for b in observed['barriers'].values())
    and observed['actualStateControl']['verified'])
(output / 'semantic-qualification.json').write_text(json.dumps(observed, indent=2) + '\n')
selected = set(output.glob('*.json')) | set(output.glob('*.trx')) | set(output.glob('*.log')) | set(output.glob('*.ps1')) | set(output.glob('*.py'))
for directory in [scenario.parent, partial.parent, control.parent]:
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in {'.json', '.log', '.txt'}:
            selected.add(path)
manifest = []
with zipfile.ZipFile(output / 'captured-artifacts.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(selected):
        manifest.append(shared.file_record(path))
        archive.write(path, path.relative_to(root).as_posix())
    archive.writestr('capture-manifest.json', json.dumps({'files': manifest}, indent=2))
print(json.dumps({'passed': observed['passed'], 'barriers': len(observed['barriers'])}, indent=2))
raise SystemExit(0 if observed['passed'] else 1)
